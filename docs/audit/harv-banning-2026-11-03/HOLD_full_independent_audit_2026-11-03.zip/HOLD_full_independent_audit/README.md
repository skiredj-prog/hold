# Reproducing this audit

Prepared 3 November 2026. Read HOLD_full_evidence_audit_2026-11-03.md first.

Inputs are the two original ZIP archives; they are not duplicated in this bundle.
Use Python 3.10 or newer. No dependencies or project installation are needed.

```sh
python3 audit.py /path/to/HOLD_E1_A6_EXTERNAL_AUDIT_FULL.zip /path/to/HOLD_A6_Audit_Documents_Email.zip --out reproduced
```

Exit 2 is EXPECTED for this evidence: 22 frozen raw-byte source hashes differ because the exported source uses CRLF. The hashes all match after diagnostic LF normalization, but the script preserves the raw-byte failures. Exit 1 indicates an additional mismatch; 0 means no mismatch.

The script generates audit_results.json, check_ledger.json and run_counts.csv. It reads ZIP bytes and JSON and inspects literal source syntax; it never imports or executes HOLD code, invokes its evaluator, or calls a model or network service. All six mutation controls must detect the intended corruption or execution stops with an assertion.

Files:
- HOLD_full_evidence_audit_2026-11-03.md: report, exact evidence references and ten-row verdict table (C1–C5 documented; A1–A5 auditor-defined).
- claim_verdicts.csv: the same ten propositions, origins, verdicts and qualifications.
- audit.py: independent auditor.
- audit_results.json: integrity, recovered counts, all 99 runs, 237 action checks, 153 decision checks and 45 authority checks.
- check_ledger.json: every assertion and exact archive/record reference.
- run_counts.csv: one row per original run, including both completion definitions.
- reproduction_check.json: identical hashes across two executions.
- Note_for_Aziz.txt: technically qualified sendable summary; it has not been sent.
- MANIFEST_SHA256.txt: hashes of these deliverables, excluding itself.

`violations` in run_counts.csv is the independently reconstructed benchmark-compatible category count/list. Omitted fields and strict-provenance sensitivity are separate in audit_results.json. Do not silently equate these conventions or equate factual completion with legitimate completion.

The previous spot-check remains separately preserved in the parent outputs folder; it is not overwritten. Snapshot SHA-256 values:
- HOLD_independent_spot_check_2026-11-03.md: 93eaa5329d61d0c8f4c7f924462029a2985adce146cf5cb5c5763d56a854ea21
- HOLD_evidence_checks.json: e17c345d7b060167828898bdcb2f8f9aa81d371041e20630662cb4a33e9ee876
